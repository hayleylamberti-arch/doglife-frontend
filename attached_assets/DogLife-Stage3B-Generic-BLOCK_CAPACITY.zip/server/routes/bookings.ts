import type { Express, Request, Response } from "express";
import prisma from "../lib/prisma.js";
import {
  createBookingNotification,
  notifySupplierNewBooking,
} from "../utils/notifications.js";
import {
  sendBookingRequestEmail,
  sendSupplierBookingRequestEmail,
  sendBookingCancelledEmail,
} from "../emailTemplates.js";
import { authenticateToken } from "../middleware/authMiddleware.js";
import {
  BookingModel,
  BookingStatus,
  BookingEventType,
  CalendarEventType,
  NotificationType,
  ServiceType,
  ReviewRole,
} from "@prisma/client";

function addMinutes(date: Date, minutes: number) {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

function overlaps(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date) {
  return aStart < bEnd && aEnd > bStart;
}

function formatDateTimeZA(startAt: Date, endAt: Date) {
  const formatter = new Intl.DateTimeFormat("en-ZA", {
    timeZone: "Africa/Johannesburg",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });

  return `${formatter.format(startAt)} - ${formatter.format(endAt)}`;
}

function formatServiceLabel(serviceType?: ServiceType | string | null) {
  return String(serviceType || "Booking")
    .replace(/_/g, " ")
    .toLowerCase();
}

function firstNameOnly(value?: string | null) {
  if (!value) return "";
  return String(value).trim().split(/\s+/)[0] || "";
}

function formatServiceEnumLabel(value?: string | null) {
  return String(value || "")
    .toLowerCase()
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function sanitizeDogNameList(
  dogs: Array<{ dog?: { name?: string | null } } | any>
) {
  return dogs
    .map((bookingDog) => firstNameOnly(bookingDog?.dog?.name))
    .filter(Boolean)
    .join(", ");
}

function buildSupplierDogProfileSummary(
  dogs: Array<{ dog?: any }>
) {
  return dogs
    .map((bookingDog: any) => {
      const dog = bookingDog.dog as any;

      if (!dog) return null;

      return [
        `${firstNameOnly(dog.name)}:`,
        dog.breed ? `Breed: ${dog.breed}` : null,
        dog.size ? `Size: ${dog.size}` : null,
        dog.sex ? `Sex: ${dog.sex}` : null,
        dog.vaccinationUpToDate != null
          ? `Vaccinated: ${dog.vaccinationUpToDate ? "Yes" : "No"}`
          : dog.isVaccinated != null
          ? `Vaccinated: ${dog.isVaccinated ? "Yes" : "No"}`
          : null,
        dog.goodWithDogs != null
          ? `Good with dogs: ${dog.goodWithDogs ? "Yes" : "No"}`
          : null,
        dog.goodWithChildren != null
          ? `Good with children: ${dog.goodWithChildren ? "Yes" : "No"}`
          : null,
        dog.behaviourNotes
          ? `Behaviour notes: ${dog.behaviourNotes}`
          : null,
        dog.behavioralNotes
          ? `Behaviour notes: ${dog.behavioralNotes}`
          : null,
        dog.medicalNotes ? `Medical notes: ${dog.medicalNotes}` : null,
      ]
        .filter(Boolean)
        .join(" | ");
    })
    .filter(Boolean)
    .join("\n\n");
}

function getEffectiveBookingModel(service: {
  service: ServiceType;
  bookingModel?: BookingModel | null;
}): BookingModel {
  if (service.bookingModel) {
    return service.bookingModel;
  }

  switch (service.service) {
    case ServiceType.BOARDING:
    case ServiceType.PET_SITTING:
      return BookingModel.DATE_RANGE_CAPACITY;

    case ServiceType.DAYCARE:
      return BookingModel.BLOCK_CAPACITY;

    default:
      return BookingModel.APPOINTMENT;
  }
}

type BookingBlock = {
  key: string;
  label: string;
  startTime: string;
  endTime: string;
  priceCents: number;
};

type BookingBlockResolution =
  | { block: BookingBlock; error: null }
  | { block: null; error: string };

function resolveLegacyDaycareBookingBlock(params: {
  service: any;
  daycareType?: string | null;
  halfDayPeriod?: string | null;
}): BookingBlockResolution {
  if (params.service.service !== ServiceType.DAYCARE) {
    return {
      block: null,
      error: "No booking blocks are currently available for this service.",
    };
  }

  if (
    !params.daycareType ||
    !["FULL_DAY", "HALF_DAY"].includes(params.daycareType)
  ) {
    return {
      block: null,
      error: "Please select half day or full day",
    };
  }

  if (
    params.daycareType === "HALF_DAY" &&
    params.halfDayPeriod &&
    !["MORNING", "AFTERNOON"].includes(params.halfDayPeriod)
  ) {
    return {
      block: null,
      error: "Invalid half day period selected",
    };
  }

  const pricingJson = params.service.pricingJson || {};

  if (params.daycareType === "FULL_DAY") {
    return {
      block: {
        key: "FULL_DAY",
        label: "Full day",
        startTime: "09:00",
        endTime: "17:00",
        priceCents:
          Number(pricingJson.fullDayPriceCents) ||
          params.service.baseRateCents ||
          0,
      },
      error: null,
    };
  }

  const period = params.halfDayPeriod || "MORNING";

  return {
    block: {
      key: `${period}_HALF_DAY`,
      label: period === "AFTERNOON" ? "Afternoon half day" : "Morning half day",
      startTime: period === "AFTERNOON" ? "13:00" : "09:00",
      endTime: period === "AFTERNOON" ? "17:00" : "13:00",
      priceCents: Number(pricingJson.halfDayPriceCents) || 0,
    },
    error: null,
  };
}

function getJohannesburgDateKey(date: Date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Johannesburg",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);

  const year = parts.find((part) => part.type === "year")?.value;
  const month = parts.find((part) => part.type === "month")?.value;
  const day = parts.find((part) => part.type === "day")?.value;

  return `${year}-${month}-${day}`;
}

function buildBookingBlockTimes(date: Date, block: BookingBlock) {
  const dateKey = getJohannesburgDateKey(date);

  return {
    startAt: new Date(`${dateKey}T${block.startTime}:00+02:00`),
    endAt: new Date(`${dateKey}T${block.endTime}:00+02:00`),
  };
}

function isAppointmentService(service: {
  service: ServiceType;
  bookingModel?: BookingModel | null;
}) {
  return getEffectiveBookingModel(service) === BookingModel.APPOINTMENT;
}

function isHomeVisitService(
  serviceType?: ServiceType | string | null,
  notes?: string | null
) {
  if (!serviceType) return false;
  if (serviceType === "WALKING") return true;
  if (serviceType === "MOBILE_VET") return true;
  if (serviceType === "PET_TRANSPORT") return true;
  if (serviceType === "PET_SITTING") {
    return (notes || "").includes("Pet sitting location: OWNER_HOME");
  }
  if (serviceType === "TRAINING") {
    return (notes || "").toLowerCase().includes("owner home");
  }
  if (serviceType === "GROOMING") {
    return (notes || "").toLowerCase().includes("mobile grooming");
  }
  return false;
}

function isSupplierLocationService(
  serviceType?: ServiceType | string | null,
  notes?: string | null
) {
  if (!serviceType) return false;
  if (serviceType === "BOARDING") return true;
  if (serviceType === "DAYCARE") return true;
  if (serviceType === "PET_SITTING") {
    return (notes || "").includes("Pet sitting location: SITTER_HOME");
  }
  if (serviceType === "GROOMING") {
    return !(notes || "").toLowerCase().includes("mobile grooming");
  }
  return false;
}

function canRevealLocation(status: BookingStatus) {
  return (
    status === BookingStatus.CONFIRMED ||
    status === BookingStatus.IN_PROGRESS ||
    status === BookingStatus.COMPLETED_UNBILLED ||
    status === BookingStatus.COMPLETED
  );
}

function extractTransportValue(notes: string | null | undefined, label: string) {
  if (!notes) return null;
  const escapedLabel = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`${escapedLabel}:\\s*([^\\.]+)`, "i");
  return notes.match(regex)?.[1]?.trim() || null;
}

function extractServiceAreaFromNotes(notes?: string | null) {
  const address =
    extractTransportValue(notes, "Owner address") ||
    extractTransportValue(notes, "Pickup point");

  if (!address) return "Service area pending";

  const lines = address
    .split(/\n|,/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length >= 2) {
    const lastLine = lines[lines.length - 1];
    const lastLineIsPostcode = /^\d{4}$/.test(lastLine);

    if (lastLineIsPostcode) {
      // Street, suburb, province, postcode
      if (lines.length >= 4) {
        return lines[lines.length - 3];
      }

      // Street, suburb, postcode
      if (lines.length >= 3) {
        return lines[lines.length - 2];
      }
    }

    return lines[1];
  }

  const parts = address.trim().split(/\s+/);
  const lastPart = parts[parts.length - 1];
  const hasPostcode = /^\d{4}$/.test(lastPart);

  if (hasPostcode && parts.length >= 3) {
    const possibleProvince = parts[parts.length - 2].toLowerCase();

    const provinceNames = new Set([
      "gauteng",
      "limpopo",
      "mpumalanga",
      "freestate",
      "kwazulu-natal",
      "northwest",
    ]);

    if (
      provinceNames.has(possibleProvince) &&
      parts.length >= 4
    ) {
      return parts[parts.length - 3];
    }

    return parts[parts.length - 2];
  }

  return "Service area pending";
}

function removeSensitiveNotes(notes?: string | null) {
  if (!notes) return null;

  return notes
    .replace(/Owner address:\s*[^.]+\.?/gi, "")
    .replace(/Access instructions:\s*[^.]+\.?/gi, "")
    .replace(/Gate code:\s*[^.]+\.?/gi, "")
    .replace(/Estate access:\s*[^.]+\.?/gi, "")
    .replace(/Alarm:\s*[^.]+\.?/gi, "")
    .replace(/Key:\s*[^.]+\.?/gi, "")
    .replace(/Pickup point:\s*[^.]+\.?/gi, "")
    .replace(/Drop-off point:\s*[^.]+\.?/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

function removeTransportMetadataFromNotes(notes?: string | null) {
  if (!notes) return null;

  const cleaned = notes
    .replace(/Journey type:\s*(?:ONE_WAY|ONE WAY|RETURN)\.?/gi, "")
    .replace(/Return date and time:\s*[^.\n]+\.?/gi, "")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();

  return cleaned || null;
}

function cleanBookingNotesForDisplay(notes?: string | null) {
  if (!notes) return null;

  const cleaned = notes
    .replace(/Journey type:\s*(?:ONE_WAY|ONE WAY|RETURN)\.?/gi, "")
    .replace(/Owner address:\s*[^.\n]+\.?/gi, "")
    .replace(/Pickup point:\s*[^.\n]+\.?/gi, "")
    .replace(/Drop-off point:\s*[^.\n]+\.?/gi, "")
    .replace(/Return pickup point:\s*[^.\n]+\.?/gi, "")
    .replace(/Return drop-off point:\s*[^.\n]+\.?/gi, "")
    .replace(/Return date and time:\s*[^.\n]+\.?/gi, "")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();

  return cleaned || null;
}

function buildServiceLocationSummary(booking: any) {
  if (!canRevealLocation(booking.status)) return null;

  const serviceType = booking.serviceType || booking.supplierService?.service;
  const notes = booking.notes || "";

  if (serviceType === "PET_TRANSPORT") {
  const journeyType =
    booking.journeyType ||
    extractTransportValue(notes, "Journey type") ||
    "ONE_WAY";

  const isReturnJourney =
    String(journeyType).toUpperCase().replace(/\s+/g, "_") === "RETURN";

  return {
    type: "TRANSPORT",
    label: isReturnJourney
      ? "Outbound and return journeys"
      : "Pickup and drop-off",

    journeyType: isReturnJourney ? "RETURN" : "ONE_WAY",

    pickupAddress: extractTransportValue(notes, "Pickup point"),
    dropoffAddress: extractTransportValue(notes, "Drop-off point"),

    returnPickupAddress: isReturnJourney
      ? extractTransportValue(notes, "Return pickup point")
      : null,

    returnDropoffAddress: isReturnJourney
      ? extractTransportValue(notes, "Return drop-off point")
      : null,

    returnStartAt: isReturnJourney
      ? booking.returnStartAt || null
      : null,

    returnEndAt: isReturnJourney
      ? booking.returnEndAt || null
      : null,
  };
}

  if (isHomeVisitService(serviceType, notes)) {
    return {
      type: "OWNER_HOME",
      label: "Owner address",
      addressLine: extractTransportValue(notes, "Owner address"),
    };
  }

  if (isSupplierLocationService(serviceType, notes)) {
  const supplierAddressParts = [
    booking.supplier?.businessAddress,
    booking.supplier?.suburb,
  ]
    .map((value) => String(value || "").trim())
    .filter(Boolean);

  return {
    type: "SUPPLIER_LOCATION",
    label: "Supplier address",
    addressLine:
      supplierAddressParts.length > 0
        ? supplierAddressParts.join("\n")
        : null,
  };
}

  return null;
}

function sanitizeBookingForOwner(booking: any) {
  const revealLocation = canRevealLocation(booking.status);

  return {
    // Core booking information
    id: booking.id,
    ownerId: booking.ownerId,
    supplierId: booking.supplierId,
    supplierServiceId: booking.supplierServiceId,

    serviceType: booking.serviceType,
    status: booking.status,

    startAt: booking.startAt,
    endAt: booking.endAt,

    journeyType: booking.journeyType ?? null,
    returnStartAt: booking.returnStartAt ?? null,
    returnEndAt: booking.returnEndAt ?? null,

    totalCents: booking.totalCents ?? 0,

    completedAt: booking.completedAt ?? null,
    createdAt: booking.createdAt,
    updatedAt: booking.updatedAt,

    // Owner-created information
    notes: cleanBookingNotesForDisplay(booking.notes),

    // The owner supplied these instructions, so the owner may continue
    // seeing them before the booking starts.
    accessInstructions: booking.accessInstructions ?? null,
    accessInstructionsUpdatedAt:
      booking.accessInstructionsUpdatedAt ?? null,

    healthSafetyAcceptedAt:
      booking.healthSafetyAcceptedAt ?? null,
    healthSafetyVersion:
      booking.healthSafetyVersion ?? null,

    // Related booking data required by the owner interface
    supplierService: booking.supplierService ?? null,
    dogs: booking.dogs ?? [],
    events: booking.events ?? [],

    owner: booking.owner
      ? {
          id: booking.owner.id,
          firstName: booking.owner.firstName,
        }
      : null,

    supplier: booking.supplier
      ? {
          id: booking.supplier.id,
          userId: booking.supplier.userId,
          businessName: booking.supplier.businessName,

          businessAddress: revealLocation
            ? booking.supplier.businessAddress
            : null,

          suburb: booking.supplier.suburb ?? null,

          ratingAverage:
            booking.supplier.ratingAverage ?? null,
          ratingCount:
            booking.supplier.ratingCount ?? 0,
          completedBookingsCount:
            booking.supplier.completedBookingsCount ?? 0,

          user: booking.supplier.user
            ? {
                id: booking.supplier.user.id,
                firstName: booking.supplier.user.firstName,
              }
            : null,
        }
      : null,

    serviceLocationSummary: revealLocation
      ? buildServiceLocationSummary(booking)
      : null,

    ownerReview: booking.reviews?.[0] || null,
    hasOwnerReviewed: Boolean(booking.reviews?.length),
  };
}

function isCapacityBasedService(service?: {
  concurrentCapacityDogs?: number | null;
}) {
  return (
    service?.concurrentCapacityDogs != null &&
    service.concurrentCapacityDogs > 0
  );
}

async function getOverlappingDogCount(params: {
  supplierId: string;
  supplierServiceId: string;
  startDate: Date;
  endDate: Date;
}) {
  const overlappingBookings = await prisma.booking.findMany({
    where: {
      supplierId: params.supplierId,
      supplierServiceId: params.supplierServiceId,
      startAt: { lt: params.endDate },
      endAt: { gt: params.startDate },
      status: {
        in: [
          BookingStatus.PENDING,
          BookingStatus.CONFIRMED,
          BookingStatus.IN_PROGRESS,
        ],
      },
    },
    include: {
      dogs: {
        select: {
          dogId: true,
        },
      },
    },
  });

  return overlappingBookings.reduce(
    (total, booking) => total + booking.dogs.length,
    0
  );
}

export function setupBookingRoutes(app: Express) {
  console.log("✅ Booking routes loaded");

  app.post("/api/bookings", authenticateToken, async (req, res) => {
    try {
      const user = (req as any).user;
      const ownerId = user?.id || user?.userId;

      const {
        supplierId,
        supplierServiceId,
        serviceSessionId,
        serviceType,
        startAt,
        endAt,
        journeyType,
        returnStartAt,
        returnEndAt,
        dogIds,
        dogCount,
        kennelType,
        notes,
        accessInstructions,
        healthSafetyAccepted,
        groomingSelections,
        daycareType,
        halfDayPeriod,
        petSittingLocation,
        mobileVetOffering,
      } = req.body;

      if (!ownerId) {
        return res.status(401).json({ ok: false, error: "Unauthorized" });
      }

      if (!supplierId || !startAt || !endAt) {
        return res
          .status(400)
          .json({ ok: false, error: "Missing required fields" });
      }

      if (!healthSafetyAccepted) {
        return res.status(400).json({
          ok: false,
          error: "Please accept the Health & Safety Policy before booking.",
        });
      }

      let startDate = new Date(startAt);
      let endDate = new Date(endAt);

      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res
          .status(400)
          .json({ ok: false, error: "Invalid booking dates" });
      }

      if (endDate <= startDate) {
  return res
    .status(400)
    .json({ ok: false, error: "End date must be after start date" });
}

const normalizedJourneyType =
  serviceType === "PET_TRANSPORT" && journeyType === "RETURN"
    ? "RETURN"
    : serviceType === "PET_TRANSPORT"
    ? "ONE_WAY"
    : null;

let parsedReturnStartAt: Date | null = null;
let parsedReturnEndAt: Date | null = null;

if (normalizedJourneyType === "RETURN") {
  if (!returnStartAt || !returnEndAt) {
    return res.status(400).json({
      ok: false,
      error: "Please select a return date and time",
    });
  }

  parsedReturnStartAt = new Date(returnStartAt);
  parsedReturnEndAt = new Date(returnEndAt);

  if (
    Number.isNaN(parsedReturnStartAt.getTime()) ||
    Number.isNaN(parsedReturnEndAt.getTime())
  ) {
    return res.status(400).json({
      ok: false,
      error: "Invalid return journey date or time",
    });
  }

  if (parsedReturnEndAt <= parsedReturnStartAt) {
    return res.status(400).json({
      ok: false,
      error: "Return journey end time must be after its start time",
    });
  }

  if (parsedReturnStartAt < endDate) {
    return res.status(400).json({
      ok: false,
      error: "Return journey must start after the outbound journey ends",
    });
  }
}

let service = null;

      if (supplierServiceId) {
        service = await prisma.supplierService.findUnique({
          where: { id: supplierServiceId },
          include: { pricingTiers: true },
        });
      } else if (serviceType) {
        service = await prisma.supplierService.findFirst({
          where: { supplierId, service: serviceType },
          include: { pricingTiers: true },
        });
      }

      if (!service) {
        return res.status(404).json({ ok: false, error: "Service not found" });
      }

      if (service.supplierId !== supplierId) {
        return res.status(400).json({
          ok: false,
          error: "Selected service does not belong to this supplier",
        });
      }

      let serviceSession = null;
      let resolvedBookingBlock: BookingBlock | null = null;

      const effectiveBookingModel = getEffectiveBookingModel(service);
      const isSessionEventBooking =
        effectiveBookingModel === BookingModel.SESSION_EVENT;

      if (effectiveBookingModel === BookingModel.BLOCK_CAPACITY) {
        const resolution = resolveLegacyDaycareBookingBlock({
          service,
          daycareType,
          halfDayPeriod,
        });

        if (resolution.error) {
          return res.status(400).json({
            ok: false,
            error: resolution.error,
          });
        }

        resolvedBookingBlock = resolution.block;

        const blockTimes = buildBookingBlockTimes(startDate, resolution.block);
        startDate = blockTimes.startAt;
        endDate = blockTimes.endAt;
      }

      if (isSessionEventBooking) {
        if (!serviceSessionId) {
          return res.status(400).json({
            ok: false,
            error: "Please select a class or course session",
          });
        }

        serviceSession = await prisma.serviceSession.findFirst({
          where: {
            id: String(serviceSessionId),
            supplierServiceId: service.id,
          },
        });

        if (!serviceSession) {
          return res.status(404).json({
            ok: false,
            error: "Selected class or course session was not found",
          });
        }

        if (!serviceSession.isActive || serviceSession.cancelledAt) {
          return res.status(400).json({
            ok: false,
            error: "This class or course session is no longer available",
          });
        }

        if (serviceSession.endAt <= new Date()) {
          return res.status(400).json({
            ok: false,
            error: "This class or course session has already ended",
          });
        }

        startDate = serviceSession.startAt;
        endDate = serviceSession.endAt;
      }

      const serviceAvailabilityBlock =
        await prisma.serviceAvailabilityBlock.findFirst({
          where: {
            serviceId: service.id,
            startAt: { lt: endDate },
            endAt: { gt: startDate },
          },
        });

      if (serviceAvailabilityBlock) {
        return res.status(400).json({
          ok: false,
          error: "This service is unavailable on the selected date",
        });
      }

      if (parsedReturnStartAt && parsedReturnEndAt) {
  const returnAvailabilityBlock =
    await prisma.serviceAvailabilityBlock.findFirst({
      where: {
        serviceId: service.id,
        startAt: { lt: parsedReturnEndAt },
        endAt: { gt: parsedReturnStartAt },
      },
    });

  if (returnAvailabilityBlock) {
    return res.status(400).json({
      ok: false,
      error: "This service is unavailable for the selected return time",
    });
  }
}

      const bufferMinutes = service.bufferMinutes || 0;

const supportServices: ServiceType[] = [
  ServiceType.MOBILE_VET,
  ServiceType.PET_TRANSPORT,
];

const isSupportService = supportServices.includes(service.service as ServiceType);

if (isAppointmentService(service)) {
        const existingBookings = await prisma.booking.findMany({
          where: {
            supplierId,
            ...(isSupportService ? { supplierServiceId: service.id } : {}),
            status: {
              in: [
                BookingStatus.PENDING,
                BookingStatus.CONFIRMED,
                BookingStatus.IN_PROGRESS,
              ],
            },
            startAt: { lt: addMinutes(endDate, bufferMinutes) },
            endAt: { gt: addMinutes(startDate, -bufferMinutes) },
          },
          include: {
            supplierService: {
              select: {
                bufferMinutes: true,
              },
            },
          },
        });

        const conflictingBooking = existingBookings.find((booking) => {
          const blockedEnd = addMinutes(
            booking.endAt,
            booking.supplierService?.bufferMinutes || 0
          );

          return overlaps(startDate, endDate, booking.startAt, blockedEnd);
        });

        if (conflictingBooking) {
          return res.status(400).json({
            ok: false,
            error: "This slot is no longer available",
          });
        }

        if (parsedReturnStartAt && parsedReturnEndAt) {
  const returnExistingBookings = await prisma.booking.findMany({
    where: {
      supplierId,
      supplierServiceId: service.id,
      status: {
        in: [
          BookingStatus.PENDING,
          BookingStatus.CONFIRMED,
          BookingStatus.IN_PROGRESS,
        ],
      },
      OR: [
        {
          startAt: {
            lt: addMinutes(parsedReturnEndAt, bufferMinutes),
          },
          endAt: {
            gt: addMinutes(parsedReturnStartAt, -bufferMinutes),
          },
        },
        {
          returnStartAt: {
            lt: addMinutes(parsedReturnEndAt, bufferMinutes),
          },
          returnEndAt: {
            gt: addMinutes(parsedReturnStartAt, -bufferMinutes),
          },
        },
      ],
    },
  });

  if (returnExistingBookings.length > 0) {
    return res.status(400).json({
      ok: false,
      error: "The selected return time is no longer available",
    });
  }
}
      }

      const capacityBased = isCapacityBasedService(service);

      if (
        !capacityBased &&
        !isAppointmentService(service) &&
        !isSessionEventBooking
      ) {
        const existing = await prisma.booking.findFirst({
          where: {
            supplierId,
            startAt: { lt: endDate },
            endAt: { gt: startDate },
            status: {
              in: [BookingStatus.PENDING, BookingStatus.CONFIRMED],
            },
          },
        });

        if (existing) {
          return res.status(400).json({
            ok: false,
            error: "This slot is no longer available",
          });
        }
      }

      const overlapping = await prisma.calendarEvent.findFirst({
        where: {
          supplierId,
          startAt: { lt: endDate },
          endAt: { gt: startDate },
          type: {
            in: [CalendarEventType.BOOKED, CalendarEventType.BLOCKED],
          },
        },
      });

      const isCapacityService =
        effectiveBookingModel === BookingModel.DATE_RANGE_CAPACITY ||
        effectiveBookingModel === BookingModel.BLOCK_CAPACITY;

      if (
        overlapping &&
        !isAppointmentService(service) &&
        !isCapacityService &&
        !isSessionEventBooking
      ) {
        return res.status(400).json({
          ok: false,
          error: "Time slot already booked",
        });
      }

      if (!Array.isArray(dogIds) || dogIds.length === 0) {
        return res
          .status(400)
          .json({ ok: false, error: "At least one dog must be selected" });
      }

      const dogs = await prisma.dog.findMany({
        where: {
          id: { in: dogIds },
          ownerId,
        },
        select: { id: true, size: true },
      });

      if (!dogs.length) {
        return res
          .status(400)
          .json({ ok: false, error: "No valid dogs selected" });
      }

      if (dogs.length !== dogIds.length) {
        return res.status(400).json({
          ok: false,
          error: "One or more selected dogs are invalid",
        });
      }

      const validDogs: Array<{ id: string; size: string | null }> = dogs;
      const selectedDogsCount = validDogs.length;

      if (serviceSession) {
        const bookedDogs = await prisma.bookingDog.count({
          where: {
            booking: {
              serviceSessionId: serviceSession.id,
              status: {
                in: [
                  BookingStatus.PENDING,
                  BookingStatus.CONFIRMED,
                  BookingStatus.IN_PROGRESS,
                ],
              },
            },
          },
        });

        if (bookedDogs + selectedDogsCount > serviceSession.capacityDogs) {
          return res.status(400).json({
            ok: false,
            error: "This class or course does not have enough spaces remaining",
          });
        }
      }

      if (
        service.maxDogsPerBooking != null &&
        selectedDogsCount > service.maxDogsPerBooking
      ) {
        return res.status(400).json({
          ok: false,
          error: `Maximum dogs per booking is ${service.maxDogsPerBooking}`,
        });
      }

if (!isSupportService) {
  const overlappingDogBooking = await prisma.booking.findFirst({
    where: {
      status: {
        in: [
          BookingStatus.PENDING,
          BookingStatus.CONFIRMED,
          BookingStatus.IN_PROGRESS,
        ],
      },
      startAt: { lt: endDate },
      endAt: { gt: startDate },
      dogs: {
        some: {
          dogId: {
            in: validDogs.map((dog) => dog.id),
          },
        },
      },
    },
    include: {
      supplierService: {
        select: {
          service: true,
        },
      },
    },
  });

  if (
    overlappingDogBooking &&
    !supportServices.includes(
      overlappingDogBooking.supplierService?.service as ServiceType
    )
  ) {
    return res.status(400).json({
      ok: false,
      error:
        "This dog already has another booking during these dates. Please choose different dates or cancel the existing booking first.",
    });
  }
} 

      if (
        !isSessionEventBooking &&
        !isAppointmentService(service) &&
        service.concurrentCapacityDogs != null
      ) {
        const overlappingDogCount = await getOverlappingDogCount({
          supplierId,
          supplierServiceId: service.id,
          startDate,
          endDate,
        });

        if (
          overlappingDogCount + selectedDogsCount >
          service.concurrentCapacityDogs
        ) {
          return res.status(400).json({
            ok: false,
            error: `Supplier can only handle ${service.concurrentCapacityDogs} dogs at this time`,
          });
        }
      }

      if (service.service === "GROOMING") {
        if (!groomingSelections || typeof groomingSelections !== "object") {
          return res.status(400).json({
            ok: false,
            error: "Please select grooming option and dog size for each dog",
          });
        }

        const missingSelection = validDogs.some((dog) => {
          const selection = groomingSelections[dog.id];
          return !selection?.category || !selection?.size;
        });

        if (missingSelection) {
          return res.status(400).json({
            ok: false,
            error: "Please select grooming option and dog size for each dog",
          });
        }
      }

      if (
        service.service === "PET_SITTING" &&
        petSittingLocation &&
        !["OWNER_HOME", "SITTER_HOME"].includes(petSittingLocation)
      ) {
        return res.status(400).json({
          ok: false,
          error: "Invalid pet sitting location selected",
        });
      }

      let totalCents = service.baseRateCents || 0;

      const msPerDay = 1000 * 60 * 60 * 24;
      const daySpan = Math.max(
        1,
        Math.ceil((endDate.getTime() - startDate.getTime()) / msPerDay)
      );

      if (serviceSession) {
        const dogsCount = Math.max(
          1,
          Number(dogCount || selectedDogsCount || 1)
        );

      totalCents = serviceSession.priceCents * dogsCount;

      } else if (
        effectiveBookingModel === BookingModel.BLOCK_CAPACITY &&
        resolvedBookingBlock
      ) {
        const dogsCount = Math.max(
          1,
          Number(dogCount || selectedDogsCount || 1)
        );

        totalCents = resolvedBookingBlock.priceCents;

        if ((service as any).additionalDogEnabled && dogsCount > 1) {
          totalCents +=
            ((service as any).additionalDogPriceCents || 0) *
            (dogsCount - 1);
        } else if (!(service as any).additionalDogEnabled && dogsCount > 1) {
          totalCents *= dogsCount;
        }
      } else if (service.service === "BOARDING") {
        const dogsCount = Math.max(
          1,
          Number(dogCount || selectedDogsCount || 1)
        );
        const baseNightRate = service.baseRateCents || 0;

        totalCents = baseNightRate * daySpan;

        if ((service as any).additionalDogEnabled && dogsCount > 1) {
          totalCents +=
            ((service as any).additionalDogPriceCents || 0) *
            (dogsCount - 1) *
            daySpan;
        } else if (!(service as any).additionalDogEnabled && dogsCount > 1) {
          totalCents = baseNightRate * daySpan * dogsCount;
        }

        if (kennelType === "PRIVATE") {
          totalCents += Math.round(totalCents * 0.15);
        }
      } else if (service.service === "GROOMING") {
        totalCents = 0;

        for (const dog of validDogs) {
          const selection = groomingSelections?.[dog.id];

          if (!selection?.category || !selection?.size) {
            return res.status(400).json({
              ok: false,
              error: "Missing grooming selection for one or more dogs",
            });
          }

          const tier = service.pricingTiers.find(
            (pricingTier) =>
              pricingTier.category === selection.category &&
              pricingTier.dogSize === selection.size
          );

          if (!tier) {
            return res.status(400).json({
              ok: false,
              error: "Invalid grooming option selected",
            });
          }

          totalCents += tier.priceCents;
        }
      } else if (service.service === "PET_SITTING") {
  const dogsCount = Math.max(
    1,
    Number(dogCount || selectedDogsCount || 1)
  );

  const baseRateCents = service.baseRateCents || 0;

  const bookingPeriods =
    service.unit === "PER_DAY" || service.unit === "PER_NIGHT"
      ? daySpan
      : 1;

  totalCents = baseRateCents * bookingPeriods;

  if ((service as any).additionalDogEnabled && dogsCount > 1) {
    const extraDogs = dogsCount - 1;

    if ((service as any).additionalDogPriceCents) {
      totalCents +=
        extraDogs *
        (service as any).additionalDogPriceCents *
        bookingPeriods;
    } else if ((service as any).additionalDogDiscountPct) {
      const discountedAdditionalDogRate = Math.round(
        baseRateCents *
          (1 -
            ((service as any).additionalDogDiscountPct || 0) / 100)
      );

      totalCents +=
        extraDogs *
        discountedAdditionalDogRate *
        bookingPeriods;
    } else {
      totalCents += extraDogs * baseRateCents * bookingPeriods;
    }
  } else if (dogsCount > 1) {
    totalCents *= dogsCount;
  }
        } else if (service.service === "MOBILE_VET") {
  const mobileVetServices = Array.isArray(
    (service as any).pricingJson?.mobileVetServices
  )
    ? (service as any).pricingJson.mobileVetServices
    : [];

  const selectedMobileVetService = mobileVetServices.find(
    (item: any) => item.key === mobileVetOffering
  );

  totalCents =
    (Number(selectedMobileVetService?.priceCents) ||
      service.baseRateCents ||
      0) * selectedDogsCount;
} else if (service.service === "PET_TRANSPORT") {
  const oneWayPriceCents = service.baseRateCents || 0;

  totalCents =
    normalizedJourneyType === "RETURN"
      ? oneWayPriceCents * 2
      : oneWayPriceCents;
} else {
        totalCents = service.baseRateCents || 0;

        if ((service as any).additionalDogEnabled && selectedDogsCount > 1) {
          const extraDogs = selectedDogsCount - 1;

          if ((service as any).additionalDogPriceCents) {
            totalCents += extraDogs * (service as any).additionalDogPriceCents;
          }

          if ((service as any).additionalDogDiscountPct) {
            const discount =
              (service.baseRateCents || 0) *
              (((service as any).additionalDogDiscountPct || 0) / 100) *
              extraDogs;

            totalCents -= Math.round(discount);
          }
        }
      }

      const noteParts: string[] = [];

      if (service.service === "BOARDING" && kennelType) {
      noteParts.push(`Kennel type: ${kennelType}.`);
      }

      if (service.service === "DAYCARE" && daycareType) {
        noteParts.push(`Daycare type: ${daycareType}.`);
      }

      if (
        service.service === "DAYCARE" &&
        daycareType === "HALF_DAY" &&
        halfDayPeriod
      ) {
        noteParts.push(`Half day period: ${halfDayPeriod}.`);
      }

      if (service.service === "PET_SITTING" && petSittingLocation) {
        noteParts.push(`Pet sitting location: ${petSittingLocation}.`);
      }

      if (service.service === "MOBILE_VET" && mobileVetOffering) {
  const mobileVetServices = Array.isArray((service as any).pricingJson?.mobileVetServices)
    ? (service as any).pricingJson.mobileVetServices
    : [];

  const selectedMobileVetService = mobileVetServices.find(
    (item: any) => item.key === mobileVetOffering
  );

  noteParts.push(
    `Mobile vet service: ${
      selectedMobileVetService?.label || formatServiceEnumLabel(mobileVetOffering)
    }.`
  );
}

      if (notes && String(notes).trim()) {
  const cleanedIncomingNotes =
    service.service === ServiceType.PET_TRANSPORT
      ? removeTransportMetadataFromNotes(String(notes))
      : String(notes).trim();

  if (cleanedIncomingNotes) {
    noteParts.push(cleanedIncomingNotes);
  }
}

      const finalNotes = noteParts.length > 0 ? noteParts.join(" ") : null;

      const booking = await prisma.booking.create({
        data: {
          ownerId,
          supplierId,
          supplierServiceId: service.id,
          serviceSessionId: serviceSession?.id || null,
          serviceType: service.service,
          totalCents,
          startAt: startDate,
          endAt: endDate,
          journeyType: normalizedJourneyType,
          returnStartAt: parsedReturnStartAt,
          returnEndAt: parsedReturnEndAt,
          status: BookingStatus.PENDING,
          notes: finalNotes,
          accessInstructions:
            accessInstructions && String(accessInstructions).trim()
              ? String(accessInstructions).trim()
              : null,
          accessInstructionsUpdatedAt:
            accessInstructions && String(accessInstructions).trim()
              ? new Date()
              : null,
          healthSafetyAcceptedAt: new Date(),
          healthSafetyVersion: "v1.0",
          dogs: {
            create: validDogs.map((dog) => ({
              dogId: dog.id,
            })),
          },
        },
        include: {
  owner: {
    select: {
      id: true,
      firstName: true,
      email: true,
    },
  },
  supplier: {
    select: {
      id: true,
      userId: true,
      businessName: true,
      businessAddress: true,
      suburb: true,
      user: {
        select: {
          id: true,
          firstName: true,
          email: true,
        },
      },
    },
  },
  dogs: {
    include: {
      dog: {
        select: {
          id: true,
          name: true,
          breed: true,
          size: true,
          sex: true,
          isVaccinated: true,
          vaccinationExpiryDate: true,
          goodWithDogs: true,
          goodWithChildren: true,
          behavioralNotes: true,
          medicalNotes: true,
        },
      },
    },
  },
  supplierService: true,
},
      });

      await prisma.calendarEvent.create({
        data: {
          supplierId,
          title: `${service.service} booking (${validDogs.length} dog${
            validDogs.length > 1 ? "s" : ""
          })`,
          startAt: startDate,
          endAt: endDate,
          type: CalendarEventType.BOOKED,
          referenceId: booking.id,
        },
      });

      if (parsedReturnStartAt && parsedReturnEndAt) {
  await prisma.calendarEvent.create({
    data: {
      supplierId,
      title: `PET_TRANSPORT return (${validDogs.length} dog${
        validDogs.length > 1 ? "s" : ""
      })`,
      startAt: parsedReturnStartAt,
      endAt: parsedReturnEndAt,
      type: CalendarEventType.BOOKED,
      referenceId: `${booking.id}:return`,
    },
  });
}

      await prisma.bookingEvent.create({
        data: {
          bookingId: booking.id,
          type: BookingEventType.BOOKING_CREATED,
          message: "Booking created",
        },
      });

      const outboundDateTime = formatDateTimeZA(
      booking.startAt,
      booking.endAt
      );

      const dateTime =
      booking.returnStartAt && booking.returnEndAt
        ? `${outboundDateTime} | Return: ${formatDateTimeZA(
        booking.returnStartAt,
        booking.returnEndAt
      )}`
    : outboundDateTime;
      const ownerFacingDogNames = booking.dogs
        .map((bookingDog) => bookingDog.dog.name)
        .join(", ");
      const supplierFacingDogNames = sanitizeDogNameList(booking.dogs);
      const isSupplierPremisesBooking = isSupplierLocationService(
        booking.supplierService?.service || booking.serviceType,
        booking.notes
      );

      const serviceArea = isSupplierPremisesBooking
        ? booking.supplier.suburb || "Service area pending"
        : extractServiceAreaFromNotes(booking.notes);
      const safeSupplierNotes = removeSensitiveNotes(booking.notes);
      const serviceLabel = formatServiceLabel(
        booking.supplierService?.service || booking.serviceType
      );
      const supplierNotificationServiceLabel =
  booking.serviceType === ServiceType.PET_TRANSPORT
    ? booking.journeyType === "RETURN"
      ? "return pet transport"
      : "one-way pet transport"
    : serviceLabel;

      await Promise.all([
        createBookingNotification({
          userId: booking.ownerId,
          bookingId: booking.id,
          title: "Booking request sent",
          message: "Your booking request has been sent.",
          type: NotificationType.BOOKING_REQUESTED,
          url: `/owner/dashboard?bookingId=${booking.id}`,
        }),

      notifySupplierNewBooking({
        supplierUserId: booking.supplier.userId,
        bookingId: booking.id,
        ownerName: booking.owner.firstName,
        serviceLabel: `${supplierNotificationServiceLabel} for ${supplierFacingDogNames}`,
      }),
    ]);

      const dogProfileSummary = buildSupplierDogProfileSummary(booking.dogs);

      await sendBookingRequestEmail(
        booking.owner.email,
        booking.owner.firstName,
        {
          id: booking.id,
          serviceName: String(
            booking.supplierService?.service || booking.serviceType
          ),
          dogNames: ownerFacingDogNames,
          providerName: booking.supplier.businessName || "DogLife supplier",
          dateTime,
          duration: "",
          location: "Awaiting supplier confirmation",
          suburb: serviceArea,
          totalCost: ((booking.totalCents || 0) / 100).toFixed(2),
        }
      );

      await sendSupplierBookingRequestEmail(
        booking.supplier.user.email,
        booking.supplier.businessName || booking.supplier.user.firstName,
        {
          id: booking.id,
          serviceName:
            formatServiceEnumLabel(
              String(booking.supplierService?.service || booking.serviceType)
            ) || "Booking",
          ownerName: booking.owner.firstName || "Owner",
          dogNames: supplierFacingDogNames,
          dogProfileSummary,
          dateTime,
          location:
            service.service === "PET_SITTING" && petSittingLocation === "SITTER_HOME"
              ? "Pet sitting at sitter’s home"
              : service.service === "PET_SITTING" && petSittingLocation === "OWNER_HOME"
              ? "Pet sitting at owner’s home"
              : "Booking request pending confirmation",
          suburb: serviceArea,
          notes: safeSupplierNotes,
          totalCost: ((booking.totalCents || 0) / 100).toFixed(2),
        }
      );

      return res.status(201).json({
        ok: true,
        booking: sanitizeBookingForOwner(booking),
      });
    } catch (err) {
      console.error("❌ BOOKING ERROR FULL:", err);

      return res.status(500).json({
        ok: false,
        error: err instanceof Error ? err.message : "Unknown error",
      });
    }
  });

  app.get(
    "/api/bookings",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = (req as any).user;
        const ownerId = user?.id || user?.userId;

        if (!ownerId) {
          return res.status(401).json({ ok: false, error: "Unauthorized" });
        }

        const bookings = await prisma.booking.findMany({
          where: { ownerId },
          include: {
            owner: {
              select: {
                id: true,
              },
            },
            supplier: {
              select: {
                businessName: true,
                businessAddress: true,
                ratingAverage: true,
                ratingCount: true,
                completedBookingsCount: true,
              },
            },
            dogs: {
              include: {
                dog: {
                  select: {
                    id: true,
                    name: true,
                    breed: true,
                    size: true,
                    profileImageUrl: true,
                  },
               },
            },
          },
            supplierService: true,
            reviews: {
              where: {
                reviewerId: ownerId,
                role: ReviewRole.OWNER_ABOUT_SUPPLIER,
              },
              select: {
                id: true,
                rating: true,
                comment: true,
                createdAt: true,
              },
            },
            events: true,
          },
          orderBy: {
            startAt: "asc",
          },
        });

        return res.json({
          ok: true,
          bookings: bookings.map((booking: any) =>
            sanitizeBookingForOwner(booking)
          ),
        });
      } catch (err) {
        console.error("❌ GET BOOKINGS ERROR:", err);
        return res
          .status(500)
          .json({ ok: false, error: "Failed to fetch bookings" });
      }
    }
  );

  app.patch(
    "/api/bookings/:id/access-instructions",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = (req as any).user;
        const ownerId = user?.id || user?.userId;
        const bookingId = String(req.params.id);
        const { accessInstructions } = req.body;

        if (!ownerId) {
          return res.status(401).json({ ok: false, error: "Unauthorized" });
        }

        const booking = await prisma.booking.findUnique({
          where: { id: bookingId },
          include: {
            supplier: true,
          },
        });

        if (!booking) {
          return res.status(404).json({ ok: false, error: "Booking not found" });
        }

        if (booking.ownerId !== ownerId) {
          return res.status(403).json({ ok: false, error: "Not allowed" });
        }

        if (
          booking.status === BookingStatus.COMPLETED ||
          booking.status === BookingStatus.CANCELLED
        ) {
          return res.status(400).json({
            ok: false,
            error: "Cannot update access instructions for this booking",
          });
        }

        const updated = await prisma.booking.update({
          where: { id: bookingId },
          data: {
            accessInstructions:
              accessInstructions && String(accessInstructions).trim()
                ? String(accessInstructions).trim()
                : null,
            accessInstructionsUpdatedAt: new Date(),
          },
        });

        await createBookingNotification({
          userId: booking.supplier.userId,
          bookingId,
          title: "Access instructions updated",
          message: "Access instructions were updated for this booking.",
          type: NotificationType.BOOKING_UPDATED,
          url: `/supplier/dashboard?bookingId=${bookingId}`,
        });

        return res.json({
          ok: true,
          booking: updated,
        });
      } catch (err) {
        console.error("❌ UPDATE ACCESS INSTRUCTIONS ERROR:", err);
        return res.status(500).json({
          ok: false,
          error: "Failed to update access instructions",
        });
      }
    }
  );

  app.patch(
    "/api/bookings/:id/cancel",
    authenticateToken,
    async (req: Request, res: Response) => {
      try {
        const user = (req as any).user;
        const bookingId = String(req.params.id);

        const booking = await prisma.booking.findUnique({
          where: { id: bookingId },
          include: {
            owner: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
            supplier: {
              include: {
                user: {
                  select: {
                    email: true,
                    firstName: true,
                  },
                },
              },
            },
            dogs: {
              include: {
                dog: true,
              },
            },
            supplierService: true,
          },
        });

        if (!booking) {
          return res.status(404).json({ ok: false, error: "Booking not found" });
        }

        if (booking.ownerId !== user.id && booking.ownerId !== user.userId) {
          return res.status(403).json({ ok: false, error: "Not allowed" });
        }

        if (booking.status === BookingStatus.COMPLETED) {
          return res
            .status(400)
            .json({ ok: false, error: "Cannot cancel completed booking" });
        }

        const [updated] = await prisma.$transaction([
          prisma.booking.update({
            where: { id: bookingId },
            data: {
              status: BookingStatus.CANCELLED,
            },
          }),
          prisma.bookingEvent.create({
            data: {
              bookingId,
              type: BookingEventType.CANCELLED,
              message: "Booking cancelled by owner",
            },
          }),
          prisma.notification.create({
            data: {
              userId: booking.supplier.userId,
              title: "Booking cancelled",
              message: "This booking was cancelled.",
              type: NotificationType.BOOKING_CANCELLED,
              referenceId: bookingId,
            },
          }),
        ]);

        await prisma.calendarEvent.deleteMany({
          where: {
            type: CalendarEventType.BOOKED,
            referenceId: {
              in: [bookingId, `${bookingId}:return`],
            },
          },
        });

        await sendBookingCancelledEmail(
          booking.supplier.user.email,
          booking.supplier.businessName || booking.supplier.user.firstName,
          {
            ownerName: booking.owner.firstName || "Owner",
            dogNames: sanitizeDogNameList(booking.dogs),
            serviceType: booking.supplierService?.service || booking.serviceType,
            dateTime: formatDateTimeZA(booking.startAt, booking.endAt),
          }
        );

        return res.json({
          ok: true,
          booking: updated,
        });
      } catch (err) {
        console.error("❌ CANCEL BOOKING ERROR:", err);
        return res
          .status(500)
          .json({ ok: false, error: "Failed to cancel booking" });
      }
    }
  );
}
