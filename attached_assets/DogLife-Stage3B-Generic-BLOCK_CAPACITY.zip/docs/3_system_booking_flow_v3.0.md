# ⚙️ DogLife — System Booking Flow  
**Version:** 3.0  
**Last Updated:** March 2026  

---

🧩 System-level booking flow — end-to-end data path (frontend → backend → database → email).


## 🧭 Overview  
This document describes the **system-wide booking architecture** that powers the DogLife platform.  

It connects the **frontend (owners and suppliers)**, **Express backend**, **Prisma ORM**, **Neon database**, and **SendGrid** for email notifications.  

The goal is to ensure that all booking activity — from creation to completion — follows a transparent, traceable, and secure workflow.  

This flow also supports **analytics**, **email automation**, and **lifecycle event logging** for operational insights.

## Booking-model dispatch

Booking creation is dispatched by the effective `SupplierService.bookingModel`:

| Booking model | Engine behaviour |
|---|---|
| `APPOINTMENT` | Individual time-slot booking with appointment conflict and buffer rules |
| `DATE_RANGE_CAPACITY` | Capacity across an arrival/departure date range |
| `BLOCK_CAPACITY` | Capacity inside a named block of a day |
| `SESSION_EVENT` | Capacity inside a scheduled service session |

`BLOCK_CAPACITY` is service-agnostic. Engine-level timing, validation, pricing and capacity decisions must use `bookingModel === BLOCK_CAPACITY`, not `service === DAYCARE`.

### Stage 3B compatibility boundary

Daycare is currently the only configured source of booking blocks. Its existing request fields (`daycareType` and `halfDayPeriod`), user-facing wording, prices, times and booking notes are preserved through a legacy compatibility resolver that produces the generic internal booking-block shape.

A non-Daycare service marked `BLOCK_CAPACITY` fails closed until a later stage supplies a valid block-definition source. The frontend must not apply Daycare defaults, and the backend returns `400` with `No booking blocks are currently available for this service.`

Supplier-configurable blocks and the Pet Visit setup and user experience are deferred to later stages. `ServiceAvailabilityBlock` continues to represent service unavailability and must not be used as a bookable block definition.

---

Frontend (Owner / Supplier)
↓
Express Server (API Gateway)
↓
Prisma ORM (Database Layer)
↓
Neon PostgreSQL (Persistent Store)
↓
SendGrid (Email Notifications)
↓
Logging / Analytics (BookingEvent)

---

## 🧩 System Components  

| Component | Description |
|------------|--------------|
| **Frontend (React / Next.js)** | Owner and supplier dashboards that send API requests via HTTPS |
| **Backend (Express + Node.js)** | Central API server managing routes, authentication, and rate limiting |
| **ORM (Prisma)** | Maps the data model to Neon PostgreSQL for structured persistence |
| **Database (Neon)** | Primary data store for all bookings, users, and event logs |
| **Notifications (SendGrid)** | Sends transactional emails for booking lifecycle events |
| **Monitoring (BookingEvent)** | Logs all state changes for analytics, debugging, and auditing |

---

## 🔐 Security & Middleware  

The backend uses a consistent security layer for both user types:

```ts
app.set("trust proxy", 1);
app.use(express.json());
app.use(helmet());
app.use(cors({ origin: true, credentials: true }));
app.use(compression());
app.use(morgan("dev"));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));

	•	Helmet → secures headers
	•	CORS → enables cross-origin requests from trusted clients
	•	Compression → optimizes responses
	•	Rate Limiting → protects from abuse
     •	Trust Proxy → required for accurate rate-limit tracking on Replit / Vercel

1️⃣ Owner submits booking form
   → POST /api/bookings
   → Prisma writes to Neon DB
   → status = PENDING
   → BookingEvent = BOOKING_CREATED
   → SendGrid: owner confirmation + supplier notification

2️⃣ Supplier dashboard
   → GET /api/supplier/bookings?status=PENDING
   → Supplier accepts/declines
   → PATCH /api/supplier/bookings/:id/accept|decline
   → status updates + BookingEvent logged
   → SendGrid emails triggered

3️⃣ Service completed
   → PATCH /api/bookings/:id/complete
   → status = COMPLETED
   → BookingEvent = COMPLETED
   → SendGrid “Thank You” / review prompt

4️⃣ Admin analytics
   → GET /api/admin/booking-stats
   → Aggregates total bookings, confirmation rates, revenue metrics

🧱 Data Flow Summary
Flow	Source	Target	Description
Owner → API	Web form submission	Express /api/bookings	Creates new booking
API → DB	Express routes	Neon via Prisma	Writes booking + event
DB → Supplier	BookingEvent	Supplier dashboard	New booking appears as PENDING
Supplier → API	Accept/Decline	Express /api/supplier/bookings/:id/...	Updates status
API → Email	Express hooks	SendGrid	Sends notifications
DB → Analytics	Prisma queries	/api/admin/booking-stats	Aggregates lifecycle data

🧬 Data Model Relationships

Booking (Core)
	•	Owned by one owner
	•	Assigned to one supplier
	•	Has multiple BookingEvents

BookingEvent (Lifecycle Audit)
	•	Logs every significant change:
	•	BOOKING_CREATED
	•	SUPPLIER_ACCEPTED
	•	SUPPLIER_DECLINED
	•	COMPLETED
	•	CANCELLED

model Booking {
  id          String          @id @default(cuid())
  ownerId     String
  supplierId  String
  serviceType String
  status      BookingStatus   @default(PENDING)
  totalCents Int?
  createdAt   DateTime        @default(now())
  updatedAt   DateTime        @updatedAt
  events      BookingEvent[]
}

model BookingEvent {
  id          String            @id @default(cuid())
  bookingId   String
  type        BookingEventType
  message     String?
  createdAt   DateTime          @default(now())
  booking     Booking           @relation(fields: [bookingId], references: [id], onDelete: Cascade)

  @@index([bookingId, createdAt])
}

⚙️ API Overview

Public Routes

Method	Endpoint	Description
POST	/api/bookings	Create new booking
GET	/api/bookings	Fetch owner bookings
PATCH	/api/bookings/:id/complete	Mark as completed

Supplier Routes

Method	Endpoint	Description
GET	/api/supplier/bookings	Fetch supplier’s bookings
PATCH	/api/supplier/bookings/:id/accept	Accept a booking
PATCH	/api/supplier/bookings/:id/decline	Decline a booking

Admin Routes

Method	Endpoint	Description
GET	/api/admin/booking-stats	Retrieve metrics dashboard
GET	/api/health	Health check endpoint

📊 Admin Analytics Endpoint

// GET /api/admin/booking-stats
import { prisma } from "@/lib/prisma";

export async function GET() {
  const stats = await prisma.booking.groupBy({
    by: ["status"],
    _count: { _all: true },
  });
  return Response.json({
    total: stats.reduce((sum, s) => sum + s._count._all, 0),
    breakdown: stats,
  });
}

Outputs Example:

{
  "total": 124,
  "breakdown": [
    { "status": "PENDING", "_count": { "_all": 10 } },
    { "status": "CONFIRMED", "_count": { "_all": 90 } },
    { "status": "COMPLETED", "_count": { "_all": 22 } },
    { "status": "CANCELLED", "_count": { "_all": 2 } }
  ]
}

🧾 Testing Scenarios (Hoppscotch / Postman)

Test	Endpoint	Expected Response
Health Check	/api/health	{ ok: true }
Create Booking	POST /api/bookings	New booking object (status = PENDING)
Supplier Accept	PATCH /api/supplier/bookings/:id/accept	Updated booking (status = CONFIRMED)
Decline	PATCH /api/supplier/bookings/:id/decline	Updated booking (status = CANCELLED)
Complete	PATCH /api/bookings/:id/complete	Updated booking (status = COMPLETED)
Admin Stats	GET /api/admin/booking-stats	Aggregated data summary

🧠 Future Enhancements
	•	📈 Integrate real-time booking analytics dashboards
	•	🔔 Add push/in-app notifications for suppliers
	•	🧾 Export booking history as CSV or PDF
	•	🧪 Implement event-driven architecture (Webhooks for analytics service)
	•	🧰 Add booking refund logic (future Stripe integration)


⸻

📎 Tags

#DogLife #System #Architecture #Express #Prisma #SendGrid #Neon #API #Documentation

---

### 🗺️ System Flow References

📘 [Backend Booking Flow Diagram](backend_booking_flow.pdf)  
*(Illustrates full data movement across Browser → API → Prisma → Neon → SendGrid.)*

📘 [User Booking Flow Diagram](user_booking_flow.pdf)  
*(Visualizes the frontend user experience and booking lifecycle.)*
